"""Dropless Top-2 MoE decoder with training-only CVCR instrumentation."""

from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F

from .config import ModelConfig
from .cvcr import CreditPredictor, ProbeSampler, inject_counterfactual_credit


class RMSNorm(nn.Module):
    def __init__(self, hidden_size: int, eps: float) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.eps = eps

    def forward(self, hidden: torch.Tensor) -> torch.Tensor:
        value = hidden.float()
        value = value * torch.rsqrt(value.square().mean(-1, keepdim=True) + self.eps)
        return value.to(hidden.dtype) * self.weight.to(hidden.dtype)


def rotate_half(value: torch.Tensor) -> torch.Tensor:
    first, second = value.chunk(2, dim=-1)
    return torch.cat((-second, first), dim=-1)


class Attention(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        self.query_heads = config.num_attention_heads
        self.kv_heads = config.num_key_value_heads
        self.head_dim = config.head_dim
        hidden = config.hidden_size
        self.query = nn.Linear(hidden, self.query_heads * self.head_dim, bias=False)
        self.key = nn.Linear(hidden, self.kv_heads * self.head_dim, bias=False)
        self.value = nn.Linear(hidden, self.kv_heads * self.head_dim, bias=False)
        self.output = nn.Linear(hidden, hidden, bias=False)

    def forward(
        self, hidden: torch.Tensor, cosine: torch.Tensor, sine: torch.Tensor
    ) -> torch.Tensor:
        batch, sequence, _ = hidden.shape
        query = self.query(hidden).view(
            batch, sequence, self.query_heads, self.head_dim
        ).transpose(1, 2)
        key = self.key(hidden).view(
            batch, sequence, self.kv_heads, self.head_dim
        ).transpose(1, 2)
        value = self.value(hidden).view(
            batch, sequence, self.kv_heads, self.head_dim
        ).transpose(1, 2)
        cosine = cosine.to(query.dtype)
        sine = sine.to(query.dtype)
        query = query * cosine + rotate_half(query) * sine
        key = key * cosine + rotate_half(key) * sine
        attended = F.scaled_dot_product_attention(
            query,
            key,
            value,
            is_causal=True,
            enable_gqa=self.query_heads != self.kv_heads,
        )
        return self.output(attended.transpose(1, 2).contiguous().view(batch, sequence, -1))


class ExpertBank(nn.Module):
    """SwiGLU experts with jagged grouped GEMM and an exact loop fallback."""

    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        experts = config.num_experts
        hidden = config.hidden_size
        intermediate = config.expert_intermediate_size
        self.backend = config.expert_backend
        self.gate_up = nn.Parameter(torch.empty(experts, 2 * intermediate, hidden))
        self.down = nn.Parameter(torch.empty(experts, hidden, intermediate))

    def _grouped(
        self,
        hidden: torch.Tensor,
        expert_ids: torch.Tensor,
        detach_parameters: bool,
    ) -> torch.Tensor:
        order = expert_ids.argsort(stable=True)
        inverse = order.argsort(stable=True)
        sorted_hidden = hidden.index_select(0, order).to(torch.bfloat16)
        sorted_experts = expert_ids.index_select(0, order)
        unique, counts = sorted_experts.unique_consecutive(return_counts=True)
        offsets = counts.cumsum(0).to(torch.int32)
        gate_up = self.gate_up.detach() if detach_parameters else self.gate_up
        down = self.down.detach() if detach_parameters else self.down
        gate_up = gate_up.index_select(0, unique)
        down = down.index_select(0, unique)
        gate_up = gate_up.to(torch.bfloat16)
        down = down.to(torch.bfloat16)
        # torch 2.11's native kernel consumes [group, K, N], despite an older
        # functional docstring describing the common weight as [group, N, K].
        projected = F.grouped_mm(
            sorted_hidden, gate_up.transpose(1, 2).contiguous(), offs=offsets
        )
        gate, up = projected.chunk(2, dim=-1)
        activated = F.silu(gate) * up
        result = F.grouped_mm(
            activated, down.transpose(1, 2).contiguous(), offs=offsets
        )
        return result.index_select(0, inverse)

    def _loop(
        self,
        hidden: torch.Tensor,
        expert_ids: torch.Tensor,
        detach_parameters: bool,
    ) -> torch.Tensor:
        output = torch.empty_like(hidden)
        gate_up = self.gate_up.detach() if detach_parameters else self.gate_up
        down = self.down.detach() if detach_parameters else self.down
        for expert in expert_ids.unique():
            index = int(expert.item())
            mask = expert_ids == expert
            values = hidden[mask]
            projected = F.linear(values, gate_up[index])
            gate, up = projected.chunk(2, dim=-1)
            output[mask] = F.linear(F.silu(gate) * up, down[index])
        return output

    def forward_assignments(
        self,
        hidden: torch.Tensor,
        expert_ids: torch.Tensor,
        *,
        detach_parameters: bool = False,
    ) -> torch.Tensor:
        if not hidden.numel():
            return torch.empty_like(hidden)
        if self.backend == "grouped_mm" and hidden.is_cuda:
            return self._grouped(hidden, expert_ids, detach_parameters)
        return self._loop(hidden, expert_ids, detach_parameters)


class MoELayer(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        self.config = config
        self.router = nn.Linear(config.hidden_size, config.num_experts, bias=False)
        self.experts = ExpertBank(config)
        if config.cvcr_enabled:
            self.credit_predictor = CreditPredictor(
                config.hidden_size, config.num_experts, config.cvcr_rank
            )
            self.probe_sampler = ProbeSampler(
                config.num_experts,
                config.probe_fraction,
                config.probe_probability_floor,
                config.probe_sampler,
                config.abp_ema_decay,
            )
            self.cvcr_active = True
        else:
            self.credit_predictor = None
            self.probe_sampler = None
            self.cvcr_active = False

    def _router_auxiliary(
        self, logits: torch.Tensor, selected_ids: torch.Tensor
    ) -> torch.Tensor:
        probabilities = logits.float().softmax(dim=-1)
        dispatch = torch.zeros_like(probabilities)
        dispatch.scatter_(1, selected_ids, 1.0 / selected_ids.shape[-1])
        balance = self.config.num_experts * (
            probabilities.mean(dim=0) * dispatch.mean(dim=0)
        ).sum()
        z_loss = logits.float().logsumexp(dim=-1).square().mean()
        return (
            self.config.router_aux_loss_coefficient * balance
            + self.config.router_z_loss_coefficient * z_loss
        )

    def forward(self, hidden: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        original_shape = hidden.shape
        flat = hidden.reshape(-1, hidden.shape[-1])
        logits = self.router(flat.float())
        top_logits, selected_ids = logits.topk(self.config.experts_per_token, dim=-1)
        selected_weights = top_logits.softmax(dim=-1).to(flat.dtype)

        assignment_hidden = flat.repeat_interleave(self.config.experts_per_token, dim=0)
        assignment_ids = selected_ids.reshape(-1)
        assignment_outputs = self.experts.forward_assignments(
            assignment_hidden, assignment_ids
        )
        selected_outputs = assignment_outputs.view(
            flat.shape[0], self.config.experts_per_token, flat.shape[-1]
        )
        mixed = (selected_outputs * selected_weights[..., None]).sum(dim=1)
        router_auxiliary = self._router_auxiliary(logits, selected_ids)
        predictor_loss = mixed.new_zeros(())

        if self.training and self.config.cvcr_enabled and self.cvcr_active:
            assert self.credit_predictor is not None
            assert self.probe_sampler is not None
            interval = self.config.cvcr_update_interval
            active_rows, probe_ids, inclusion = self.probe_sampler.sample(
                selected_ids, self.config.probe_fraction * interval
            )
            projected_hidden = self.credit_predictor.projected_hidden(flat.detach())
            if active_rows.numel():
                probe_outputs = self.experts.forward_assignments(
                    flat.detach().index_select(0, active_rows),
                    probe_ids,
                    detach_parameters=True,
                ).detach()
                predicted = self.credit_predictor.selected_outputs(
                    projected_hidden.index_select(0, active_rows), probe_ids
                )
                squared_error = (predicted.float() - probe_outputs.float()).square().mean(dim=-1)
                predictor_loss = (
                    interval
                    * self.config.predictor_loss_coefficient
                    * squared_error.mean()
                )
                # Uniform sampling does not consume the residual-variance EMA;
                # avoid an otherwise needless reduction on the hot path.
                if self.config.probe_sampler == "abp":
                    self.probe_sampler.observe_residuals(
                        probe_ids, squared_error.detach()
                    )
            else:
                probe_outputs = flat.new_empty((0, flat.shape[-1]))
                predictor_loss = predictor_loss + 0.0 * sum(
                    parameter.reshape(-1)[0]
                    for parameter in self.credit_predictor.parameters()
                )
            mixed = inject_counterfactual_credit(
                mixed,
                logits,
                selected_ids,
                selected_outputs,
                mixed.detach(),
                active_rows,
                probe_ids,
                probe_outputs,
                inclusion,
                projected_hidden,
                self.credit_predictor,
                interval * self.config.cvcr_coefficient,
            )
        return mixed.view(original_shape), router_auxiliary, predictor_loss


class DecoderBlock(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        self.attention = Attention(config)
        self.moe = MoELayer(config)
        self.input_norm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.post_attention_norm = RMSNorm(config.hidden_size, config.rms_norm_eps)

    def forward(
        self, hidden: torch.Tensor, cosine: torch.Tensor, sine: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        hidden = hidden + self.attention(self.input_norm(hidden), cosine, sine)
        moe_output, router_auxiliary, predictor_loss = self.moe(
            self.post_attention_norm(hidden)
        )
        return hidden + moe_output, router_auxiliary, predictor_loss


class MoELanguageModel(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        self.config = config
        self.embedding = nn.Embedding(config.vocab_size, config.hidden_size)
        self.layers = nn.ModuleList(
            [DecoderBlock(config) for _ in range(config.num_hidden_layers)]
        )
        self.final_norm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        if config.tie_word_embeddings:
            self.lm_head.weight = self.embedding.weight
        # CVCR modules must not perturb the deployed model's initialization.
        # A method pair with the same process seed therefore starts from exactly
        # the same embeddings, attention, experts, and router parameters.
        initialization_seed = torch.initial_seed()
        deployed_generator = torch.Generator(device="cpu")
        deployed_generator.manual_seed(initialization_seed)
        for name, parameter in self.named_parameters():
            if ".credit_predictor." in name:
                continue
            if parameter.ndim > 1:
                nn.init.normal_(
                    parameter,
                    mean=0.0,
                    std=config.initializer_range,
                    generator=deployed_generator,
                )
        residual_std = config.initializer_range / math.sqrt(2 * config.num_hidden_layers)
        for layer in self.layers:
            nn.init.normal_(
                layer.attention.output.weight,
                std=residual_std,
                generator=deployed_generator,
            )
            nn.init.normal_(
                layer.moe.experts.down,
                std=residual_std,
                generator=deployed_generator,
            )
        inverse = 1.0 / (
            config.rope_theta
            ** (torch.arange(0, config.head_dim, 2).float() / config.head_dim)
        )
        frequencies = torch.outer(
            torch.arange(config.max_position_embeddings).float(), inverse
        )
        embedding = torch.cat([frequencies, frequencies], dim=-1)[None, None, :, :]
        self.register_buffer("cosine", embedding.cos(), persistent=False)
        self.register_buffer("sine", embedding.sin(), persistent=False)

    def forward(
        self, input_ids: torch.Tensor, targets: torch.Tensor | None = None
    ):
        sequence = input_ids.shape[1]
        hidden = self.embedding(input_ids)
        router_auxiliary = hidden.new_zeros(())
        predictor_loss = hidden.new_zeros(())
        for layer in self.layers:
            hidden, layer_router_auxiliary, layer_predictor_loss = layer(
                hidden,
                self.cosine[:, :, :sequence],
                self.sine[:, :, :sequence],
            )
            router_auxiliary = router_auxiliary + layer_router_auxiliary
            predictor_loss = predictor_loss + layer_predictor_loss
        logits = self.lm_head(self.final_norm(hidden))
        if targets is None:
            return logits
        cross_entropy = F.cross_entropy(
            logits.float().reshape(-1, self.config.vocab_size), targets.reshape(-1)
        )
        total = cross_entropy + router_auxiliary + predictor_loss
        return total, cross_entropy.detach(), router_auxiliary.detach(), predictor_loss.detach()

    def set_cvcr_active(self, active: bool) -> None:
        """Select the temporally batched CVCR graph for this microbatch."""
        for layer in self.layers:
            layer.moe.cvcr_active = active

    def active_flops_per_token(self, sequence_length: int) -> int:
        config = self.config
        hidden = config.hidden_size
        attention = (
            2 * hidden * hidden
            + 2 * hidden * config.num_key_value_heads * config.head_dim
        )
        experts = (
            3
            * hidden
            * config.expert_intermediate_size
            * config.experts_per_token
        )
        router = hidden * config.num_experts
        body = config.num_hidden_layers * (attention + experts + router)
        train_matmuls = 6 * (body + hidden * config.vocab_size)
        attention_matmuls = (
            12 * config.num_hidden_layers * hidden * sequence_length
        )
        return train_matmuls + attention_matmuls

    def expected_probe_flops_per_token(self) -> float:
        if not self.config.cvcr_enabled:
            return 0.0
        # One forward-only SwiGLU expert on the sampled token.
        return (
            self.config.probe_fraction
            * 6
            * self.config.hidden_size
            * self.config.expert_intermediate_size
            * self.config.num_hidden_layers
        )

    def inference_state_dict(self) -> dict[str, torch.Tensor]:
        return {
            key: value
            for key, value in self.state_dict().items()
            if ".credit_predictor." not in key and ".probe_sampler." not in key
        }
