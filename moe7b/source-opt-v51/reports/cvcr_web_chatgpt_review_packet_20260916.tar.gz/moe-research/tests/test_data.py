import json

import numpy as np
import pytest

from cvcr_moe.data import PackedReader, verify_frozen_manifest


def test_reader_produces_shifted_disjoint_batches(tmp_path) -> None:
    data = tmp_path / "pack" / "train-npy"
    data.mkdir(parents=True)
    np.save(data / "train.npy", np.arange(30, dtype=np.uint16))
    reader = PackedReader(data, seed=0, sequence_length=4)
    inputs, targets = reader.batch_for_step(0, rank=0, world_size=2, sequences_per_rank=2)
    other_inputs, _ = reader.batch_for_step(
        0, rank=1, world_size=2, sequences_per_rank=2
    )
    assert inputs.shape == (2, 4)
    assert targets.shape == (2, 4)
    assert np.array_equal(targets.numpy()[:, :-1], inputs.numpy()[:, 1:])
    assert set(map(tuple, inputs.tolist())).isdisjoint(set(map(tuple, other_inputs.tolist())))


def test_manifest_gate_fails_closed(tmp_path) -> None:
    data = tmp_path / "pack" / "train-npy"
    data.mkdir(parents=True)
    manifest = data.parent / "manifest.json"
    manifest.write_text(json.dumps({"status": "NOT_ADMITTED", "block_size": 2049}))
    with pytest.raises(ValueError, match="not admitted"):
        verify_frozen_manifest(data)
    manifest.write_text(
        json.dumps({"status": "FROZEN_VERIFIED_PACK", "block_size": 2049})
    )
    assert verify_frozen_manifest(data)["status"] == "FROZEN_VERIFIED_PACK"
