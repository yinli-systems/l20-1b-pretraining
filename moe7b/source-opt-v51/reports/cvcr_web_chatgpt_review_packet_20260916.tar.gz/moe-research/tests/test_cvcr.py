from dataclasses import replace

import torch

from cvcr_moe.config import ModelConfig
from cvcr_moe.cvcr import ProbeSampler, control_variate_estimate
from cvcr_moe.model import MoELanguageModel


def tiny_config(method: str = "top2") -> ModelConfig:
    return ModelConfig(
        vocab_size=128,
        hidden_size=32,
        expert_intermediate_size=24,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=2,
        num_experts=4,
        experts_per_token=2,
        max_position_embeddings=16,
        expert_backend="loop",
        method=method,
        cvcr_rank=4,
        probe_fraction=1.0,
    )


def test_control_variate_estimator_is_empirically_unbiased() -> None:
    generator = torch.Generator().manual_seed(7)
    baseline = torch.tensor([0.2, -0.5, 0.8])
    exact = torch.tensor([1.0, 0.25, -0.4])
    probability = torch.tensor([0.1, 0.25, 0.8])
    estimates = []
    for _ in range(100_000):
        included = torch.rand(3, generator=generator) < probability
        estimates.append(
            control_variate_estimate(baseline, exact, included, probability)
        )
    observed = torch.stack(estimates).mean(dim=0)
    torch.testing.assert_close(observed, exact, atol=0.02, rtol=0.0)


def test_abp_probabilities_have_positive_support() -> None:
    sampler = ProbeSampler(4, 1.0, 1e-4, "abp", 0.99)
    sampler.residual_variance.copy_(torch.tensor([1.0, 4.0, 9.0, 16.0]))
    selected = torch.tensor([[0, 1], [1, 2], [2, 3]])
    rows, expert, inclusion = sampler.sample(selected)
    assert rows.numel() == selected.shape[0]
    assert torch.all(inclusion > 0)
    assert torch.all(expert[:, None] != selected.index_select(0, rows))


def test_uniform_shared_probe_reports_exact_marginal_probability() -> None:
    torch.manual_seed(5)
    sampler = ProbeSampler(16, 1.0 / 16.0, 1e-4, "uniform", 0.99)
    first = torch.arange(1024) % 16
    selected = torch.stack((first, (first + 1) % 16), dim=-1)
    for _ in range(32):
        rows, expert, inclusion = sampler.sample(selected)
        assert rows.numel() == 64
        assert torch.all(expert[:, None] != selected.index_select(0, rows))
        torch.testing.assert_close(
            inclusion,
            torch.full_like(
                inclusion,
                (1.0 / 16.0) * (1.0 - (895.0 / 896.0) ** 64),
            ),
        )


def test_eval_path_matches_plain_top2_after_loading_deployed_weights() -> None:
    torch.manual_seed(11)
    top2 = MoELanguageModel(tiny_config("top2"))
    cvcr = MoELanguageModel(tiny_config("cvcr"))
    cvcr.load_state_dict(top2.state_dict(), strict=False)
    top2.eval()
    cvcr.eval()
    tokens = torch.randint(0, 128, (2, 12))
    torch.testing.assert_close(top2(tokens), cvcr(tokens), rtol=0.0, atol=0.0)


def test_cvcr_does_not_perturb_deployed_initialization() -> None:
    torch.manual_seed(17)
    top2 = MoELanguageModel(tiny_config("top2"))
    torch.manual_seed(17)
    cvcr = MoELanguageModel(tiny_config("cvcr"))
    cvcr_deployed = {
        key: value
        for key, value in cvcr.state_dict().items()
        if ".credit_predictor." not in key and ".probe_sampler." not in key
    }
    top2_state = top2.state_dict()
    assert top2_state.keys() == cvcr_deployed.keys()
    for key in top2_state:
        torch.testing.assert_close(top2_state[key], cvcr_deployed[key], rtol=0.0, atol=0.0)


def test_probes_do_not_add_expert_parameter_gradients() -> None:
    torch.manual_seed(13)
    base = replace(
        tiny_config("cvcr"),
        cvcr_coefficient=0.0,
        predictor_loss_coefficient=0.0,
        probe_fraction=0.0,
    )
    no_probes = MoELanguageModel(base)
    with_probes = MoELanguageModel(replace(base, probe_fraction=1.0))
    with_probes.load_state_dict(no_probes.state_dict())
    no_probes.train()
    with_probes.train()
    tokens = torch.randint(0, 128, (2, 12))
    targets = torch.randint(0, 128, (2, 12))
    no_probes(tokens, targets)[0].backward()
    with_probes(tokens, targets)[0].backward()
    assert len(no_probes.layers) == len(with_probes.layers)
    for no_probe_layer, probe_layer in zip(no_probes.layers, with_probes.layers):
        torch.testing.assert_close(
            no_probe_layer.moe.experts.gate_up.grad,
            probe_layer.moe.experts.gate_up.grad,
            rtol=0.0,
            atol=0.0,
        )
        torch.testing.assert_close(
            no_probe_layer.moe.experts.down.grad,
            probe_layer.moe.experts.down.grad,
            rtol=0.0,
            atol=0.0,
        )


def test_zero_credit_cvcr_preserves_all_deployed_gradients() -> None:
    torch.manual_seed(23)
    top2 = MoELanguageModel(tiny_config("top2")).train()
    cvcr = MoELanguageModel(
        replace(
            tiny_config("cvcr"),
            cvcr_coefficient=0.0,
            predictor_loss_coefficient=1e-3,
            probe_fraction=1.0,
        )
    ).train()
    cvcr.load_state_dict(top2.state_dict(), strict=False)
    tokens = torch.randint(0, 128, (2, 12))
    targets = torch.randint(0, 128, (2, 12))
    top2(tokens, targets)[0].backward()
    cvcr(tokens, targets)[0].backward()
    cvcr_parameters = dict(cvcr.named_parameters())
    for name, parameter in top2.named_parameters():
        torch.testing.assert_close(
            parameter.grad,
            cvcr_parameters[name].grad,
            rtol=0.0,
            atol=0.0,
        )


def test_inference_state_excludes_training_only_modules() -> None:
    model = MoELanguageModel(tiny_config("cvcr"))
    inference = model.inference_state_dict()
    assert inference
    assert all("credit_predictor" not in key for key in inference)
    assert all("probe_sampler" not in key for key in inference)


def test_declared_parameter_counts_match_modules() -> None:
    for method in ("top2", "cvcr"):
        config = tiny_config(method)
        model = MoELanguageModel(config)
        deployed = sum(
            parameter.numel()
            for name, parameter in model.named_parameters()
            if ".credit_predictor." not in name
        )
        training = sum(parameter.numel() for parameter in model.parameters())
        assert deployed == config.deployed_parameter_count()
        assert training == config.training_parameter_count()


def test_requested_7b_shape_has_exact_declared_counts() -> None:
    config = ModelConfig(
        vocab_size=32_000,
        hidden_size=2048,
        expert_intermediate_size=2816,
        num_hidden_layers=24,
        num_attention_heads=32,
        num_key_value_heads=4,
        num_experts=16,
        experts_per_token=2,
        tie_word_embeddings=False,
        method="cvcr",
    )
    assert config.deployed_parameter_count() == 7_002_228_736
    assert config.active_parameter_count() == 1_188_923_392


def test_cvcr_disabled_when_coefficient_is_zero() -> None:
    base = tiny_config("cvcr")
    config = replace(base, cvcr_coefficient=0.0, predictor_loss_coefficient=0.0)
    model = MoELanguageModel(config)
    model.train()
    tokens = torch.randint(0, 128, (1, 8))
    targets = torch.randint(0, 128, (1, 8))
    loss, *_ = model(tokens, targets)
    loss.backward()
    assert torch.isfinite(loss)


def test_temporally_skipped_cvcr_does_not_touch_predictor_gradients() -> None:
    config = replace(tiny_config("cvcr"), cvcr_update_interval=2, probe_fraction=0.25)
    model = MoELanguageModel(config).train()
    model.set_cvcr_active(False)
    tokens = torch.randint(0, 128, (1, 8))
    targets = torch.randint(0, 128, (1, 8))
    loss, *_ = model(tokens, targets)
    loss.backward()
    for name, parameter in model.named_parameters():
        if ".credit_predictor." in name:
            assert parameter.grad is None
